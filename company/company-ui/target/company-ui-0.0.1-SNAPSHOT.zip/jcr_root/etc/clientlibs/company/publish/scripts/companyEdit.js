Alert("This is an Alert in Publish mode");

