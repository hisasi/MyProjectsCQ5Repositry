alert("This is an Alert in Author mode");
